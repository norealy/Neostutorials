// 1. Viết 1 regex tham lam tìm ra tất cả C hoa:

let quoteSample = "C"; // Returns ["C"]
let quoteSample1 = "P1P5P4CCCP2P6P3"; // Returns ["CCC"]
let quoteSample2 = "P6P2P7P4P5CCCcCP3P1"; // Returns ["CCC", "C"]
let quoteSample3 = "CC c"; // Returns ["CC"]
let quoteSample4 = "P1P2P3"; // Returns null
let quoteSample5 = "P2P1P5P4CCCCCCCCCCCCCCCCCCCCCCCP3"; // Returns ["CCCCCCCCCCCCCCCCCCCCCCC"]
let regExpStr = /C+/g
console.log(quoteSample2.match(regExpStr))

// 2. Kiểm tra trường Usernames

// - Usernames chỉ có thể sử dụng các ký tự chữ và số
console.log('========================================');
let txtUsername = 'Nguyenvandat1998@/.,X'
let regW = /\W+/g
let standUsername = txtUsername.replace(regW,'')
console.log(standUsername)

/* 3. Các số trong usernames phải ở cuối. [abc0->9]
Có thể có 0 hoặc các số lớn hơn và 
nhiều số hơn ở cuối nhưng tuyệt đối Usernames không thể bắt đầu bằng số.*/
console.log('========================================');
txtUsername = 'NguyenVandat1998@/.,X'
let regUsername = /^[a-zA-Z]+[0-9]*/g
standUsername = txtUsername.match(regUsername)
console.log(standUsername)

// 4. Những chữ cái trong usernames có thể là chữ thường và chữ hoa.
console.log('========================================');
regUsername = /^[a-zA-Z]+/gi
standUsername = txtUsername.match(regUsername)
console.log(standUsername)

/* 5. Usernames phải dài ít nhất hai ký tự. 
Usernames có hai ký tự chỉ có thể sử dụng các ký tự chữ cái. */
console.log('========================================');
let txtTest4 = ['123ewqe123q','wqe123q','aqewqe132','Adqwewqe','qe13','a123']
regUsername = /^[a-zA-Z]{2,}\w*/g
for (let i = 0; i < txtTest4.length; i++) {
    let standUsername = txtTest4[i].match(regUsername);
    // let standUsername = regUsername.test(txtTest4[i]);
    console.log(standUsername);
}


/* 6. Reg Password
- Mật khẩu phải dài hơn 5 ký tự.
- Mật khẩu không bắt đầu bằng số.
- Phải có hai số liên tiếp trong mật khẩu. */
console.log('========================================');
let arrtxtPass = ['123ewqe123q','wqe12g','aqe132','Adqwewqe1','qe13','123']
let regPassword = /^(?=[a-zA-Z]+\d{2,}\w*)(?=\w{6,})/g
for (let i = 0; i < arrtxtPass.length; i++) {
    let standPassword = regPassword.test(arrtxtPass[i]);
    console.log(standPassword);
}


